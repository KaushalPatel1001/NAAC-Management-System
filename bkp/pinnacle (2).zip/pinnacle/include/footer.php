<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				2023 @ Pinnacle.                            
			</div>
			<div class="col-sm-6">
				<div class="text-sm-right d-none d-sm-block">
					Crafted with <i class="mdi mdi-heart text-danger"></i> by Alpine Technologies                                
				</div>
			</div>
		</div>
	</div>
</footer>