
            <div class="row">
              <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between" style="background:#fff; box-shadow: 0px 2px 3px #00000040;">

                  <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                   
                      <form class="" id="manpower_cost_estimation_form">
                          <div class="card-body">
                              <div id="newinput">
                              
                                <div class="row">
                          <div class="col-12">
                                <table class="table table-bordered dt-responsive nowrap" id="broughtout_data_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                    <th></th>
                                    <?php 
        $select_man_power = "select * from manpower order by id ASC";
        $query = mysqli_query($conn, $select_man_power);
        $man_count_rows = mysqli_num_rows($query);
        $select_activity = "select * from activity order by id ASC";
        $act_query = mysqli_query($conn, $select_activity);

        $count_rows = mysqli_num_rows($act_query);
        while($fetch_row = mysqli_fetch_array($query)){
        ?>
        <th ><?php echo $fetch_row['short_name']?> <input name="emp_type[]" type="hidden" value="<?php echo $fetch_row['id']?>" > </th>
        <?php } ?>
                                  </thead>
                                  
<tbody>
        
        <?php 
        while($fetch_row_act = mysqli_fetch_array($act_query)){
        ?>
        
        <tr>
        <td><?php echo $fetch_row_act['activity_name']?></td>
            
            <?php 
            for($i = 0; $i < $man_count_rows; $i++){
            ?>
        <td><table class="table table-bordered dt-responsive nowrap" id="broughtout_data_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;"><tr><td><input name="activity_id[]" type="hidden" value="<?php echo $fetch_row_act['id']?>" ><input name="no_of_person[]" style="width:40px" type="text"></td><td><input style="width:40px" name="no_of_days[]" type="text"></td></tr></table></td>
           <?php } ?> 
        <?php } ?>
        </tr>
        
      
        </form>       
            
       
            
        
        
    </tbody>
                                </table>
                          </div>
                        </div>
                    </div>

                              <input type="hidden" name="id" id="id" />
                              <input type="hidden" name="total_count" value="<?php echo $count_rows;?>">
                              <input type="hidden" name="emp_total_count" value="<?php echo $man_count_rows;?>">      
                              <button class="btn btn-primary" id="add_button" type="submit">Save</button>
                              <button class="btn btn-primary" id="loader" type="button" style="display:none">
                                <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                                Saving...
                              </button>


                     </div> 
                     </form>                 
                  </div>
                </div>
              </div>
            
                <button class="prev-btn">Previous</button>
                <button class="next-btn">Next</button>
            </div>


          <!-- container-fluid -->
        
    
  
