
            <!-- start page title -->
            <div class="row">
              <div class="col-12">
                <div class="card-body" style="background:#fff; box-shadow: 0px 2px 3px #00000040;">
                  <form class="" id="contractpage">            
                              <div class="row">
                          <div class="col-12">
                                <table class="table table-bordered dt-responsive nowrap" id="contract_page_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                    <tr>
                                      <th width="5%">#</th>
                                      <th width="20%">Select Contract</th>
                                      <th width="20%">UOM</th>
                                      <th width="15%">Unit Rate</th>
                                      <th width="15%">Quantity</th>
                                      <th width="15%">Total Cost</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td><button type="button" name="add_row" id="add_row" alt="1" class="btn btn-success btn-xs"><i class="mdi mdi-plus-box-multiple-outline"></i></button>
                                        <span style="display:none" id="sr_no">1</span></td>
                                      <td>
                                        <select class="custom-select select_contract" name="select_contract[]" data-srno="1" id="select_contract1" required>
                                      <option value="">-SELECT-</option>
                                     <?php
                                       $query = "SELECT contract_desc FROM contract";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $contractname){
                                     ?>
                                        <option value="<?php echo $contractname["contract_desc"];?>"><?php echo $contractname["contract_desc"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select> 
                                      </td>
                                    <td>
                                    <select class="custom-select contract_uom" name="contract_uom[]" data-srno="1" id="contract_uom1" required>
                                      <option value="">-SELECT-</option>
                                     <?php
                                       $query = "SELECT uom_name FROM uom";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $uomname){
                                     ?>
                                        <option value="<?php echo $uomname["uom_name"];?>"><?php echo $uomname["uom_name"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select>
                                    </td>
                                    <td>
                                       <input type="text" class="form-control contract_unit_rate" id="contract_unit_rate1" placeholder="UNIT RATE" name="contract_unit_rate[]" data-srno="1" onblur="validate_num_Input(this)" required>
                                    </td>
                                    <td>
                                       <input type="text" class="form-control contract_quantity" data-srno="1" id="contract_quantity1" onblur="validate_num_Input(this)" placeholder="QUANTITY" name="contract_quantity[]" required>
                                    </td>
                                    <td>
                                       <input type="text" class="form-control contract_total_cost" data-srno="1" id="contract_total_cost1" placeholder="COST" name="contract_total_cost[]" readonly>
                                    </td>
                                    </tr>
                                  </tbody>
                                </table>
                          </div>
                        </div>

                              <input type="hidden" name="id" id="id"/>
                              <input type="hidden" name="count" id="count" value="1" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>
                              </div>
              </div>
            


  </div>

<button class="prev-btn">Previous</button>
<button class="next-btn">Next</button>
<!-- JAVASCRIPT -->


<script type="text/javascript" language="javascript">
      $(document).ready(function(){
        var count = 1;
        $(document).on('click', '#add_row', function(){
          count++;
          $('#count').val(count);
          var html_code = '';
          html_code += '<tr id="row_id_'+count+'">';
          html_code += '<td><button type="button" name="remove_row" id="'+count+'" class="btn btn-danger btn-md remove_row"><i class="mdi mdi-delete"></i></button><span style="display:none" id="sr_no">'+count+'</span></td>';

          html_code += '<td class=""><select class="custom-select select_contract" style="width:350px;" name="select_contract[]" id="select_contract'+count+'" data-srno="'+count+'" required><option value="">-Select-</option><?php
           $select_query = "select * from contract where status = '1'";
           $process = mysqli_query($conn,$select_query);
           while ($fetch = mysqli_fetch_array($process)){
           $category_id = $fetch['id'];
           $category_name = $fetch['contract_desc'];
           ?>
           <option value="<?php echo $category_name;?>"><?php echo $category_name;?></option><?php } ?></select></td>';
           
           html_code += '<td class=""><select class="custom-select contract_uom" style="width:350px;" name="contract_uom[]" id="contract_uom'+count+'" data-srno="'+count+'" required><option value="">-Select-</option><?php 
           $select_query = "select * from uom where status = '1'";
           $process = mysqli_query($conn,$select_query);
           while ($fetch = mysqli_fetch_array($process)){
           $category_id = $fetch['id'];
           $category_name = $fetch['uom_name'];
           ?>
           <option value="<?php echo $category_name;?>"><?php echo $category_name;?></option><?php } ?></select></td>';
                                     
          html_code += '<td class=""><input type="text" class="form-control contract_unit_rate" id="contract_unit_rate'+count+'" name="contract_unit_rate[]" onblur="validate_num_Input(this)" data-srno="'+count+'" placeholder="UNIT RATE" required></td>';

          html_code += '<td class=""><input type="text" class="form-control contract_quantity" id="contract_quantity'+count+'" name="contract_quantity[]" onblur="validate_num_Input(this)" data-srno="'+count+'" placeholder="QUANTITY" required></td>';

          html_code += '<td class=""><input type="text" class="form-control contract_total_cost" id="contract_total_cost'+count+'" name="contract_total_cost[]" placeholder="COST" data-srno="'+count+'" readonly></td>';

          html_code += '</tr>';
          $('#contract_page_table').append(html_code);
          });
        
        $(document).on('click', '.remove_row', function(){
          var row_id = $(this).attr("id");
          $('#row_id_'+row_id).remove();
          $('#count').val(count);
        });
    


         $(document).on('keyup', '.contract_quantity', function(){
          cal_final_total(count);
        });
         $(document).on('keyup', '.contract_unit_rate', function(){
          cal_final_total(count);
        });


         function cal_final_total(count) {
          
          var contract_unit_rate = 0;
          var contract_quantity = 0;
          var contract_total_cost = 0;
          for(j=1; j<=count; j++){
          
          var contract_unit_rate = $('#contract_unit_rate'+j).val();
          var contract_quantity = $('#contract_quantity'+j).val();
          var contract_total_cost = $('#contract_total_cost'+j).val();
          var total_amt = parseFloat(contract_unit_rate) * parseFloat(contract_quantity);
            if(!isNaN(total_amt)) {
              $('#contract_total_cost'+j).val(total_amt);
            } else {
              $('#contract_total_cost'+j).val('');
            }

          
        }

      }
});


function validate_num_Input(inputField) {
      
      var inputValue = inputField.value.trim();
      // Check if the input value is empty or contains non-alphabetic characters
      if (inputValue !== '' && !/^[0-9]+$/.test(inputValue)) {
        showDangerToast_code_validation();
        inputField.value = ''; // Clear the input field
        
      }
    }

function validate_name_Input(inputField) {
      var inputValue = inputField.value.trim();

      // Check if the input value is empty or contains non-alphabetic characters
      // if (inputValue !== '' && !/^[A-Za-z]+$/.test(inputValue)) {
      //   showDangerToast_name_validation();
      //   inputField.value = ''; // Clear the input field
      //   inputField.focus(); // Set focus back to the input field
      // }
        if (inputValue == '' && (!/^[a-zA-Z0-9]+$/.test(inputValue) || inputValue.startsWith('-'))) {
        showDangerToast_name_validation();
        inputField.value = ''; // Clear the input field
        inputField.focus(); // Set focus back to the input field
       }
    }

    

</script>

</body>
</html>
