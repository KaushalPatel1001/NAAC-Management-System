            <div class="row">
              <div class="col-12">
                <div class="card-body" style="background:#fff; box-shadow: 0px 2px 3px #00000040;">
                          <form class="" id="chemical_testing" novalidate>
                              <div class="row">
                               
                                <div class="col-md-12 mb-3">                                
                                  <label for="validationCustom01">Chemical Testing</label>
                                   
                                </div>
                                <div class="col-md-2 mb-1">
                                  <label for="validationCustom01">No.Of Sample</label>
                                  <input type="number" class="form-control number" id="chemical_no_of_sample" name="chemical_no_of_sample" oninput="calculateChemical()">
                                </div>
                                <div class="col-md-2 mb-3">
                                  <label for="validationCustom01">Chemical Unit Rate</label>
                                  <input type="number" class="form-control number" id="chemical_unit_rate" name="chemical_unit_rate" onblur="validate_name_Input(this)" oninput="calculateChemical()">
                                </div>

                                <div class="col-md-2 mb-3">
                                  <label for="validationCustom01">Chemical Total Cost</label>
                                  <input type="text" class="form-control" id="chemical_total_cost" name="chemical_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>


                            <form class="" id="mechanical_testing" novalidate>
                              <div class="row">
                               
                                <div class="col-md-12 mb-3">                                
                                  <label for="validationCustom01">Mechanical Testing</label>
                                   
                                </div>
                                <div class="col-md-2 mb-1">
                                  <label for="validationCustom01">No.Of Sample</label>
                                  <input type="number" class="form-control number" id="mechanical_no_of_sample" name="mechanical_no_of_sample" oninput="calculateMechanical()">
                                </div>
                                <div class="col-md-2 mb-3">

                                  <label for="validationCustom01">Mechanical Unit Rate</label>
                                  <input type="number" class="form-control number" id="mechanical_unit_rate" name="mechanical_unit_rate"  onblur="validate_name_Input(this)" oninput="calculateMechanical()">
                                </div>

                                <div class="col-md-2 mb-3">

                                  <label for="validationCustom01">Mechanical Total Cost</label>
                                  <input type="text" class="form-control number" id="mechanical_total_cost" name="mechanical_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>

                             
                              <div class="row">
                               
                                <div class="col-md-12 mb-3">                                
                                  <label for="validationCustom01">Testing Withness</label>
                                   
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Testing Type</label>
                                  <select class="custom-select" name="testing_type" id="testing_type" onchange="toggleInputs()">
                                      <option value="">-Select-</option>
                                      <option value="Yes">Yes</option>
                                      <option value="No">No</option>
                                  </select>
                                </div> 
                                </div>

                                   
                              <form class="input-fields" id="testing" style="display: none;" novalidate>
                              <div class="row">
                                <!-- <div class="col-md-12 mb-3">                                
                                  <label for="validationCustom01">Select</label>
                                   
                                </div> -->
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Select Tpi</label>
                                  <select class="custom-select" name="testing_select_tpi" id="testing_select_tpi">
                                    <option value=""></option>
                                     <?php
                                       $query = "SELECT tpi_name FROM tpi";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $tpiname){
                                     ?>
                                        <option value="<?php echo $tpiname["tpi_name"];?>"><?php echo $tpiname["tpi_name"];?></option>
                                        <?php 
                                   }
                                     ?>
                                  </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Testing No oF Days</label>
                                  <input type="number" class="form-control number" id="testing_no_of_days" name="testing_no_of_days" oninput="calculateWithness()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Testing Unit Rate</label>
                                  <input type="number" class="form-control number" id="testing_unit_rate" name="testing_unit_rate" oninput="calculateWithness()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Testing Total Cost</label>
                                  <input type="text" class="form-control number" id="testing_total_cost" name="testing_total_cost">
                                </div>          
                              </div>
                              <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                                <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                                  Adding...
                                </button>
                              </form>

                              </div>
    </div>
  </div>
  <button class="prev-btn">Previous</button>
<button class="next-btn">Next</button>
 
 <script>

function calculateChemical() {
  var c1 = parseFloat(document.getElementById("chemical_no_of_sample").value);
  var c2 = parseFloat(document.getElementById("chemical_unit_rate").value);
  var productchemical = c1 * c2;
  
  if (!isNaN(productchemical)) {
    document.getElementById("chemical_total_cost").value = productchemical;
  } else {
    document.getElementById("chemical_total_cost").value = "";
  }
}

function calculateMechanical() {
  var m1 = parseFloat(document.getElementById("mechanical_no_of_sample").value);
  var m2 = parseFloat(document.getElementById("mechanical_unit_rate").value);
  var mechanical = m1 * m2;
  
  if (!isNaN(mechanical)) {
    document.getElementById("mechanical_total_cost").value = mechanical;
  } else {
    document.getElementById("mechanical_total_cost").value = "";
  }
}

function calculateWithness() {
 var t1 = parseFloat(document.getElementById("testing_no_of_days").value);
  var t2 = parseFloat(document.getElementById("testing_unit_rate").value);
  var testing = t1 * t2;
  
  if (!isNaN(testing)) {
    document.getElementById("testing_total_cost").value = testing;
  } else {
    document.getElementById("testing_total_cost").value = "";
  } 
}

function toggleInputs() {
    var testingType = document.getElementById("testing_type").value;
    var inputFields = document.getElementsByClassName("input-fields");
    
    if (testingType === "Yes") {
        for (var i = 0; i < inputFields.length; i++) {
            inputFields[i].style.display = "block";
        }
    } else {
        for (var i = 0; i < inputFields.length; i++) {
            inputFields[i].style.display = "none";
        }
    }
}

function validate_name_Input(inputField) {
      var inputValue = inputField.value.trim();

      // Check if the input value is empty or contains non-alphabetic characters
      // if (inputValue !== '' && !/^[\s0-9A-Za-z-]+$/.test(inputValue)) {
      //   showDangerToast_name_validation();
      //   inputField.value = inputValue; // Clear the input field
      //   inputField.focus(); // Set focus back to the input field
      // }

     if (inputValue !== '' && (!/^[a-zA-Z0-9]+$/.test(inputValue) || inputValue.startsWith('-'))) {
        showDangerToast_name_validation();
        inputField.value = ''; // Clear the input field
        inputField.focus(); // Set focus back to the input field
       }
    }

</script>	
