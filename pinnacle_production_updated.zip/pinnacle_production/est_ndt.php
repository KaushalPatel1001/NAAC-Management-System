            <div class="row">
              <div class="col-12">
                <div class="card-body" style="background:#fff; box-shadow: 0px 2px 3px #00000040;">
                      <form class="" id="ndt_ut" novalidate>
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Ut Type</label>
                                  <select class="custom-select" name="ut_type" id="ut_type" required onchange="showInputUt()">
                                    <option value="">-Select-</option>
                                    <option value="Running Meter">Running Meter</option>
                                    <option value="Day">Day</option>
                                  </select>
                                </div>
                                <div class="col-md-3 mb-3" id="inputut" style="display: none;">
                                  <label for="validationCustom01">Enter value</label>
                                  <input type="number" class="form-control number" id="ut_enter_value" name="ut_enter_value" oninput="calculateUt()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Unit Rate</label>
                                  <input type="number" class="form-control number" id="unit_rate" name="unit_rate" onblur="validate_name_Input(this);" oninput="calculateUt()">
                                </div>

                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Total Cost</label>
                                  <input type="text" class="form-control" id="total_cost" name="total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>

                            <form class="" id="ndt_pt" novalidate>
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Pt Type</label>
                                  <select class="custom-select" name="pt_type" id="pt_type" required onchange="showInputPt()">
                                    <option value="">-Select-</option>
                                    <option value="Running Meter">Running Meter</option>
                                    <option value="Kgs">Kgs</option>
                                  </select>
                                </div>
                                <div class="col-md-3 mb-3" id="inputpt" style="display: none;">
                                  <label for="validationCustom01">Enter value</label>
                                  <input type="number" class="form-control number" id="pt_enter_value" name="pt_enter_value" oninput="calculatePt()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Unit Rate</label>
                                  <input type="number" class="form-control number" id="pt_unit_rate" name="pt_unit_rate" onblur="validate_name_Input(this)" oninput="calculatePt()">
                                </div>

                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Total Cost</label>
                                  <input type="text" class="form-control number" id="pt_total_cost" name="pt_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>

                    <form class="" id="ndt_vt" novalidate>
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Vt Type</label>
                                  <select class="custom-select" name="vt_type" id="vt_type" required onchange="showInputVt(this)">
                                    <option value="">-Select-</option>
                                    <option value="Running Meter">Running Meter</option>
                                    <option value="Kgs">Kgs</option>
                                  </select>
                                </div>
                                <div class="col-md-3 mb-3" id="inputFieldContainer" style="display: none;">
                                  <label for="validationCustom01">Enter value</label>
                                  <input type="number" class="form-control number" id="vt_enter_value" name="vt_enter_value" oninput="calculateVt()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Unit Rate</label>
                                  <input type="number" class="form-control number" id="vt_unit_rate" name="vt_unit_rate" onblur="validate_name_Input(this);" oninput="calculateVt()">
                                </div>

                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Total Cost</label>
                                  <input type="text" class="form-control number" id="vt_total_cost" name="vt_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>

                          <form class="" id="ndt_rt" novalidate>
                              <div class="row">
                                <div class="col-md-3 mb-3">

                                  <label for="validationCustom01">Fix Visit Charge</label>
                                  <input type="text" class="form-control" id="rt_fix_visit_charge" name="rt_fix_visit_charge">
                                </div>
                              </div>
                              <div class="row">
                               
                                <div class="col-md-12 mb-3">                                
                                  <label for="validationCustom01">Film Charge</label>
                                   
                                </div>
                                <div class="col-md-2 mb-3">
                                  <label for="validationCustom01">Spot Size</label>
                                  <select class="custom-select" name="rt_spot_size" id="rt_spot_size" required>
                                    <option value="">-Select-</option>                         
                                    <option value="6">6</option>
                                    <option value="12">12</option>
                                    <option value="18">18</option>
                                  </select>
                                </div>
                                <div class="col-md-2 mb-1">
                                  <label for="validationCustom01">No.Of Spot</label>
                                  <input type="number" class="form-control number" id="rt_no_of_spot" name="rt_no_of_spot" oninput="calculateRt();">
                                </div>
                                <div class="col-md-2 mb-3">

                                  <label for="validationCustom01">Unit Value</label>
                                  <input type="number" class="form-control number" id="rt_unit_value" name="rt_unit_value" onblur="validate_name_Input(this);" oninput="calculateRt();">
                                </div>

                                <div class="col-md-2 mb-3">

                                  <label for="validationCustom01">Total Cost</label>
                                  <input type="text" class="form-control" id="rt_total_cost" name="rt_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>
                       
                       <form class="" id="ndt_paut" novalidate>
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Paut Type</label>
                                  <select class="custom-select" name="paut_ut_type" id="paut_ut_type" required onchange="showInputPaut()">
                                    <option value="">-Select-</option>
                                    <option value="Running Meter">Running Meter</option>
                                    <option value="Day">Day</option>
                                  </select>
                                </div>
                                <div class="col-md-3 mb-3" id="inputpaut" style="display: none;">
                                  <label for="validationCustom01">Enter value</label>
                                  <input type="number" class="form-control number" id="paut_enter_value" name="paut_enter_value" oninput="calculatePaut()">
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Unit Rate</label>
                                  <input type="number" class="form-control number" id="paut_unit_rate" name="paut_unit_rate" onblur="validate_name_Input(this);" oninput="calculatePaut()">
                                </div>

                                <div class="col-md-3 mb-3">
                                  <label for="validationCustom01">Total Cost</label>
                                  <input type="text" class="form-control" id="paut_total_cost" name="paut_total_cost">
                                </div>
                 
                              </div>
                <input type="hidden" name="id" id="id" />
                              <button class="btn btn-primary" id="add_button" type="submit">Add</button>
                <button class="btn btn-primary" id="loader" type="button" style="display:none">
                              <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                              Adding...
                </button>
                            </form>
      </div>
    </div>
  </div>
  <button class="prev-btn">Previous</button>
<button class="next-btn">Next</button>
 <script>

  function showInputVt() {
            var selectVt = document.getElementById("vt_type");
            var inputvt = document.getElementById("inputvt");
            
            if (selectVt.value === "Running Meter" || selectVt.value === "Day") {
                inputvt.style.display = "block";
            } else {
                inputvt.style.display = "none";
            }
        }

  function showInputPt() {
       var selectPt = document.getElementById("pt_type");
            var inputpt = document.getElementById("inputpt");
            
            if (selectPt.value === "Running Meter" || selectPt.value === "Day") {
                inputpt.style.display = "block";
            } else {
                inputpt.style.display = "none";
            }
  }

  function showInputUt() {
       var selectUt = document.getElementById("ut_type");
            var inputut = document.getElementById("inputut");
            
            if (selectUt.value === "Running Meter" || selectUt.value === "Day") {
                inputut.style.display = "block";
            } else {
                inputut.style.display = "none";
            }
  }


  function showInputPaut() {
       var selectPaut = document.getElementById("paut_ut_type");
            var inputpaut = document.getElementById("inputpaut");
            
            if (selectPaut.value === "Running Meter" || selectPaut.value === "Day") {
                inputpaut.style.display = "block";
            } else {
                inputpaut.style.display = "none";
            }
  }      

function calculateRt() {
  var r1 = parseFloat(document.getElementById("rt_no_of_spot").value);
  var r2 = parseFloat(document.getElementById("rt_unit_value").value);
  var rt = r1 * r2;
  
  if (!isNaN(rt)) {
    // var roundedProduct = rt.toFixed(2);
    document.getElementById("rt_total_cost").value = rt;
  } else {
    document.getElementById("rt_total_cost").value = "";
  }
}

function calculateUt() {
  var u1 = parseFloat(document.getElementById("ut_enter_value").value);
  var u2 = parseFloat(document.getElementById("unit_rate").value);
  var ut = u1 * u2;
  
  if (!isNaN(ut)) {
    // var roundedProduct = rt.toFixed(2);
    document.getElementById("total_cost").value = ut;
  } else {
    document.getElementById("total_cost").value = "";
  }
}

function calculatePt() {
  var p1 = parseFloat(document.getElementById("pt_enter_value").value);
  var p2 = parseFloat(document.getElementById("pt_unit_rate").value);
  var pt = p1 * p2;
  
  if (!isNaN(pt)) {
    // var roundedProduct = rt.toFixed(2);
    document.getElementById("pt_total_cost").value = pt;
  } else {
    document.getElementById("pt_total_cost").value = "";
  }
}

function calculateVt() {
  var v1 = parseFloat(document.getElementById("vt_enter_value").value);
  var v2 = parseFloat(document.getElementById("vt_unit_rate").value);
  var vt = v1 * v2;
  
  if (!isNaN(vt)) {
    // var roundedProduct = rt.toFixed(2);
    document.getElementById("vt_total_cost").value = vt;
  } else {
    document.getElementById("vt_total_cost").value = "";
  }
}

function calculatePaut() {
  var paut1 = parseFloat(document.getElementById("paut_enter_value").value);
  var paut2= parseFloat(document.getElementById("paut_unit_rate").value);
  var paut = paut1 * paut2;
  
  if (!isNaN(paut)) {
    // var roundedProduct = rt.toFixed(2);
    document.getElementById("paut_total_cost").value = paut;
  } else {
    document.getElementById("paut_total_cost").value = "";
  }
}

function toggleInputs() {
    var testingType = document.getElementById("testing_type").value;
    var inputFields = document.getElementsByClassName("input-fields");
    
    if (testingType === "Yes") {
        for (var i = 0; i < inputFields.length; i++) {
            inputFields[i].style.display = "block";
        }
    } else {
        for (var i = 0; i < inputFields.length; i++) {
            inputFields[i].style.display = "none";
        }
    }
}  
 
function validate_name_Input(inputField) {
      var inputValue = inputField.value.trim();

      // Check if the input value is empty or contains non-alphabetic characters
      // if (inputValue !== '' && !/^[\s0-9A-Za-z-]+$/.test(inputValue)) {
      //   showDangerToast_name_validation();
      //   inputField.value = inputValue; // Clear the input field
      //   inputField.focus(); // Set focus back to the input field
      // }

      if (inputValue !== '' && (!/^[a-zA-Z0-9]+$/.test(inputValue) || inputValue.startsWith('-'))) {
        showDangerToast_name_validation();
        inputField.value = ''; // Clear the input field
        inputField.focus(); // Set focus back to the input field
        }
    }

</script> 
