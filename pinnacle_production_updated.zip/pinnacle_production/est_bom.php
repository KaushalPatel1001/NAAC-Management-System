
                    
            <!-- start page title -->
            <div class="row">
              <div class="col-12">
                <div class="card-body" style="background:#fff; box-shadow: 0px 2px 3px #00000040; width: 1228px;">
                      <form class="" id="bill_of_material">
                          <div class="card-body">
                              <div id="newinput">
                              
                                <div class="row" style="margin-right: 20px;
    margin-left: -30px;
}">
                          <div class="col-12">
                                <table class="table table-bordered" id="bill_of_material_tabe" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                    <tr>
                                      <th width="3%">#</th>
                                      <th width="8%">Part No</th>
                                      <th width="8%">Name</th>
                                      <th width="8%">Shape</th>
                                      <th width="8%">Moc</th>
                                      <th width="8%">Length</th>
                                      <th width="8%">Breadth</th>
                                      <th width="8%">Height</th>
                                      <th width="8%">Thickness</th>
                                      <th width="8%">Density</th>
                                      <th width="8%">Uom</th>
                                      <th width="8%">Unit Qty</th>
                                      <th width="8%">Total Qty</th>
                                      <th width="8%">Unit Weight</th>
                                      <th width="8%">Total Weight</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr id="row_id_1">
                                  <td>
                                    <button type="button" name="add_row" id="add_row" alt="1" class="btn btn-success btn-xs"><i class="mdi mdi-plus-box-multiple-outline"></i></button>
                                    <span style="display:none" id="sr_no">1</span>
                                  </td>
                                  <td id="part_no_select">
                                    <select class="custom-select part_no" name="part_no[]" data-srno="1" id="part_no1" onchange="getProName(this); getInvUom(this);" placeholder="Part Number" required>
                                      <option value="">-Select-</option>
                                      <?php
                                       $query = "SELECT id,mat_code FROM mst_product";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $mat_code){
                                     ?>
                                        <option value="<?php echo $mat_code["id"];?>"><?php echo $mat_code["mat_code"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select>
                                  </td>
                                  <td id="pro_name_select">
                                     <select class="custom-select pro_name" name="pro_name[]" data-srno="1" id="pro_name1" placeholder="Product Name" onchange="getMatCode(this);" required>
                                        <option value="">-Select-</option>
                                      <?php
                                       $query = "SELECT id,pro_name FROM mst_product";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $pro_name){
                                     ?>
                                        <option value="<?php echo $pro_name["id"];?>"><?php echo $pro_name["pro_name"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select>
                                  </td>
                                  <td id="shape_select">
                                       <select class="custom-select shape" name="shape[]" data-srno="1" id="shape1" placeholder="Shape" required>
                                      <option value="">-Select-</option>
                                      <?php
                                       $query = "SELECT id,shape_name FROM shape";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $shape_name){
                                     ?>
                                        <option value="<?php echo $shape_name["id"];?>"><?php echo $shape_name["shape_name"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select>
                                  </td>
                                  <td id="grp_select">
                                    <select class="custom-select group" name="group[]" data-srno="1" id="group1" placeholder="Group" required>
                                      <option value="">-Select-</option>
                                      <?php
                                       $query = "SELECT id,grp_name FROM mst_group";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $group_name){
                                     ?>
                                        <option value="<?php echo $group_name["id"];?>"><?php echo $group_name["grp_name"];?></option>
                                        <?php 
                                   }
                                     ?>
                                    </select>
                                  </td>
                                  <td>
                                    <input type="text" class="form-control length" name="length[]" data-srno="1" id="length1" placeholder="Length" required> 
                                  </td>
                                  <td>
                                    <input type="text" class="form-control breadth" name="breadth[]" data-srno="1" id="breadth1" placeholder="Breadth" required> 
                                  </td>
                                  <td>
                                    <input type="text" class="form-control thickness" name="thickness[]" data-srno="1" id="thickness1" placeholder="Thickness" required> 
                                  </td>
                                  <td>
                                    <input type="text" class="form-control height" name="height[]" data-srno="1" id="height1" placeholder="Height" required> 
                                  </td>
                                  <td>
                                    <input type="text" class="form-control density" name="density[]" data-srno="1" id="density1" placeholder="Density" required> 
                                  </td>
                                  <td>
                                   <input type="text" class="form-control inv_uom" name="inv_uom[]" data-srno="1" id="inv_uom1" placeholder="Inv_Uom" required>
                                  </td>
                                  <td>
                                   <input type="text" class="form-control unit_qty" name="unit_qty[]" data-srno="1" id="unit_qty1" placeholder="Unit Qty" required>
                                  </td>
                                  <td>
                                   <input type="text" class="form-control total_qty" name="total_qty[]" data-srno="1" id="total_qty1" placeholder="Total Qty" required>
                                  </td>
                                  <td>
                                   <input type="text" class="form-control unit_weight" name="unit_weight[]" data-srno="1" id="unit_weight1" placeholder="Unit Weight" required>
                                  </td>
                                  <td>
                                   <input type="text" class="form-control total_weight" name="total_weight[]" data-srno="1" id="total_weight1" placeholder="Total Weight" required>
                                  </td>
                                    </tr>
                                  </tbody>
                                </table>
                          </div>
                        </div>
                    </div>

                              <input type="hidden" name="id" id="id" />
                              <input type="hidden" name="count" id="count" class="count" value="1"/>
                              <button class="btn btn-primary" id="add_button" type="submit">Save</button>
                              <button class="btn btn-primary" id="loader" type="button" style="display:none">
                                <span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>
                                Saving...
                              </button>


                     </div> 
                     </form>    
                    </div>
                </div>
              </div>
              <button class="prev-btn">Previous</button>
                <button class="next-btn">Next</button>              
                  
    <script>
     

         


      $(document).ready(function(){
        var count = 1;
        $(document).on('click', '#add_row', function(){
          count++;
          $('#count').val(count);
          var html_code = '';
          html_code += '<tr id="row_id_'+count+'">';

          html_code += '<td><button type="button" name="remove_row" id="'+count+'" class="btn btn-danger btn-md remove_row"><i class="mdi mdi-delete"></i></button><span style="display:none" id="sr_no">'+count+'</span></td>';

          html_code += '<td><select class="custom-select part_no" name="part_no[]" data-srno="1" id="part_no1" onchange="getProName(this); getInvUom(this);" placeholder="Part Number" required><option value="">-Select-</option><?php
                                       $query = "SELECT id,mat_code FROM mst_product";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $mat_code){
                                     ?>
                                        <option value="<?php echo $mat_code["id"];?>"><?php echo $mat_code["mat_code"];?></option><?php 
                                   }
                                     ?>
                                    </select></td>';

           html_code += '<td><select class="custom-select pro_name" name="pro_name[]" data-srno="1" id="pro_name1" placeholder="Product Name" onchange="getMatCode(this);" required><option value="">-Select-</option><?php
                                       $query = "SELECT id,pro_name FROM mst_product";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $pro_name){
                                     ?>
                                        <option value="<?php echo $pro_name["id"];?>"><?php echo $pro_name["pro_name"];?></option><?php 
                                   }
                                     ?>
                                    </select></td>';

          html_code += '<td><select class="custom-select shape" name="shape[]" data-srno="1" id="shape1" placeholder="Shape" required><option value="">-Select-</option><?php
                                       $query = "SELECT id,shape_name FROM shape";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $shape_name){
                                     ?>
                                        <option value="<?php echo $shape_name["id"];?>"><?php echo $shape_name["shape_name"];?></option><?php 
                                   }
                                     ?>
                                    </select></td>';

          html_code += '<td class=""><select class="custom-select group" name="group[]" data-srno="1" id="group1" placeholder="Group" required><option value="">-Select-</option><?php
                                       $query = "SELECT id,grp_name FROM mst_group";
                                       $results=mysqli_query($conn, $query);
                                       //loop
                                       foreach ($results as $group_name){
                                     ?>
                                        <option value="<?php echo $group_name["id"];?>"><?php echo $group_name["grp_name"];?></option><?php 
                                   }
                                     ?>
                                    </select></td>';

          html_code += '<td><input type="text" class="form-control length" name="length[]" data-srno="1" id="length1" placeholder="Length" required></td>';

          html_code += '<td><input type="text" class="form-control breadth" name="breadth[]" data-srno="1" id="breadth1" placeholder="Breadth" required></td>';

           html_code += '<td><input type="text" class="form-control thickness" name="thickness[]" data-srno="1" id="thickness1" placeholder="Thickness" required></td>';

          html_code += '</tr>';
          $('#broughtout_data_table').append(html_code);
          });
        
        $(document).on('click', '.remove_row', function(){
          var row_id = $(this).attr("id");
          $('#row_id_'+row_id).remove();
          $('#count').val(count);
        });

         $(document).on('change', '.quantity', function(){
          cal_final_total(count);
        });
         $(document).on('change', '.unit_rate', function(){
          cal_final_total(count);
        });


         function cal_final_total(count) {
          
          var unit_rate = 0;
          var quantity = 0;
          var total = 0;
          for(j=1; j<=count; j++){
          
          var unit_rate = $('#unit_rate'+j).val();
          var quantity = $('#quantity'+j).val();
          var total = $('#total'+j).val();
          var total_amt = parseFloat(unit_rate
            ) * parseFloat(quantity);
            if(!isNaN(total_amt)) {
              $('#total'+j).val(total_amt);
            } else {
              $('#total'+j).val('');
            }

          
        }

      }

    });
      
      function validate_num_Input(inputField) {
      
      var inputValue = inputField.value.trim();
      // Check if the input value is empty or contains non-alphabetic characters
      if (inputValue !== '' && !/^[0-9]+$/.test(inputValue)) {
        showDangerToast_code_validation();
        inputField.value = ''; // Clear the input field
        
      }
    }

 


    function validate_num_extra_Input(inputField) {
      
      var inputValue = inputField.value.trim();
      // Check if the input value is empty or contains non-alphabetic characters
      if (!/^[0-9\s]*$/.test(inputValue)) {
        showDangerToast_numonly_validation();
        inputField.value = ''; // Clear the input field
        inputField.focus(); // Set focus back to the input field
        inputField.preventDefault();
      }
    }


    function validate_empty_extra(inputField){
       var inputValue = inputField.value.trim();
       if (inputValue == '') {
        showDangerToast_name_validation();
       } 
    }

    function validate_name_Input(inputField) {
      var inputValue = inputField.value.trim();

      // Check if the input value is empty or contains non-alphabetic characters
      if (inputValue == '' && !/^[\s0-9A-Za-z-]+$/.test(inputValue)) {
        showDangerToast_name_req();
        inputField.value = ''; // Clear the input field
        inputField.focus(); // Set focus back to the input field
      }
    }

     function getMatCode(ele){

            var pro_id =  $(ele).val();
            //var currentRow = $(this).closest('tr');
             var coung = $(ele).data('srno');
            $.ajax({
              url: "fetch/fetch_matcode_by_pro_id_forBOM.php",
              type: "POST",
              data: {
                pro_id: pro_id
              },
              cache: false,
              success: function(result){
                //$('#mat_code1').val(result);
                //currentRow.find('.mat_code').val(result);
                $('#part_no'+coung).html(result);
              }
            });
          }


    function getProName(ele){
            var part_no =  $(ele).val();
            //var currentRow = $(this).closest('tr');
             var coung = $(ele).data('srno');
            $.ajax({
              url: "fetch/fetch_pro_name_by_matcode.php",
              type: "POST",
              data: {
                part_no: part_no
              },
              cache: false,
              success: function(result){
                console.log(result);
                //$('#mat_code1').val(result);
                //currentRow.find('.mat_code').val(result);
                $('#pro_name'+coung).html(result);

              }
            });
          }

    function getInvUom(ele){

            var pro_id =  $(ele).val();
            //var currentRow = $(this).closest('tr');
             var coung = $(ele).data('srno');
            $.ajax({
              url: "fetch/fetch_invuom_by_product.php",
              type: "POST",
              data: {
                pro_id: pro_id
              },
              dataType:'JSON',
              cache: false,
              success: function(result){
                
                //$('#mat_code1').val(result);
                //currentRow.find('.mat_code').val(result);
                $('#inv_uom'+coung).val(result);
              }
            });
          }


    </script>
  