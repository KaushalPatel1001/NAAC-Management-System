$(document).ready(function() {
    $('#menu_management_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#menu_name').val() == ""){
				showDangerToast_field_required();
				$('#menu_name').focus();	
				}else if($('#link').val() == ""){
				showDangerToast_field_required();
				$('#link').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=menu_management",
							type: "post",
							data: $("#menu_management_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else if($.trim(data) === 'MENU UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#menu_management_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Menu Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#menu_management_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Menu Created Successfully");
								}
                		} 
        			});
				}
			});
	
	$('#department_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#department_name').val() == ""){
				showDangerToast_field_required();
				$('#department_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=department",
							type: "post",
							data: $("#department_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#department_form")[0].reset();
								}else if($.trim(data) === 'DEPARTMENT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#department_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Department Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#department_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Department Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#category_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#cat_name').val() == ""){
				showDangerToast_field_required();
				$('#cat_name').focus();	
				}else if($('#cat_code').val() == ""){
				showDangerToast_field_required();
				$('#cat_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=category",
							type: "post",
							data: $("#category_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#category_form")[0].reset();
								}else if($.trim(data) === 'CATEGORY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#category_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("category Updated Successfully");
								}else if($.trim(data) === 'CATEGORY EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#cat_code").focus();
									var table = $('#datatable1').DataTable();
									alertify.error("category already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#category_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("category Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#group_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#grp_name').val() == ""){
				showDangerToast_field_required();
				$('#grp_name').focus();	
				}else if($('#grp_code').val() == ""){
				showDangerToast_field_required();
				$('#grp_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=group",
							type: "post",
							data: $("#group_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#group_form")[0].reset();
								}else if($.trim(data) === 'GROUP UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#group_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Group Updated Successfully");
								}else if($.trim(data) === 'GROUP EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Group already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#group_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Group Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#broughtout_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#pro_name[1]').val() == ""){
				showDangerToast_field_required();
				$('#pro_name[1]').focus();	
				}else if($('#mat_code[1]').val() == ""){
				showDangerToast_field_required();
				$('#mat_code[1]').focus();	
				}else if($('#unit_rate[1]').val() == ""){
				showDangerToast_field_required();
				$('#unit_rate[1]').focus();
				}else if($('#quantity[1]').val() == ""){
				showDangerToast_field_required();
				$('#quantity[1]').focus();	
				}else if($('#total[1]').val() == ""){
				showDangerToast_field_required();
				$('#total[1]').focus();	
				}else{
				var request;
							
							request = $.ajax({
							url: "crud.php?page=broughtout_data",
							type: "post",
							data: $("#broughtout_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){
							console.log(data); 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#broughtout_form")[0].reset();
								}else if($.trim(data) === 'BROUGHTOUT ADDED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#broughtout_form")[0].reset();
									$("#menu_manage").modal("hide");
									alertify.success("Broughtout Item added Successfully");
								}
                		} 
        			});
				}
			});


	$('#sub_group_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#sub_grp_name').val() == ""){
				showDangerToast_field_required();
				$('#sub_grp_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=sub_group",
							type: "post",
							data: $("#sub_group_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#sub_group_form")[0].reset();
								}else if($.trim(data) === 'SUB-GROUP UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#sub_group_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Sub-Group Updated Successfully");
								}else if($.trim(data) === 'SUB-GROUP EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Sub-Group already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#sub_group_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Sub-Group Created Successfully");
								}
                		} 
        			});
				}
			});

	$('#product_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#pro_name').val() == ""){
				showDangerToast_field_required();
				$('#pro_name').focus();	
				}
				else if($('#pro_code').val() == ""){
				showDangerToast_field_required();
				$('#pro_code').focus();	
				}
				else if($('#mat_code').val() == ""){
				showDangerToast_field_required();
				$('#mat_code').focus();	
				}
				else if($('#tech_spec').val() == ""){
				showDangerToast_field_required();
				$('#tech_spec').focus();	
				}
				else if($('#cat_id').val() == ""){
				showDangerToast_field_required();
				$('#cat_id').focus();	
				}
				else if($('#grp_id').val() == ""){
				showDangerToast_field_required();
				$('#grp_id').focus();	
				}
				else if($('#sub_grp_id').val() == ""){
				showDangerToast_field_required();
				$('#sub_grp_id').focus();	
				}
				else if($('#hsn').val() == ""){
				showDangerToast_field_required();
				$('#hsn').focus();	
				}
				else if($('#gst_rate').val() == ""){
				showDangerToast_field_required();
				$('#gst_rate').focus();	
				}
				else if($('#purchase_uom').val() == ""){
				showDangerToast_field_required();
				$('#purchase_uom').focus();	
				}
				else if($('#inventory_uom').val() == ""){
				showDangerToast_field_required();
				$('#inventory_uom').focus();	
				}
				else if($('#indent').val() == ""){
				showDangerToast_field_required();
				$('#indent').focus();	
				}
				else if($('#po_req').val() == ""){
				showDangerToast_field_required();
				$('#po_req').focus();	
				}
				else if($('#qc_req').val() == ""){
				showDangerToast_field_required();
				$('#qc_req').focus();	
				}
				else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}
				else{
				var request;
							request = $.ajax({
							url: "crud.php?page=product",
							type: "post",
							data: $("#product_form").serialize(),
							beforeSend: function(){
							console.log($("#product_form").serialize());
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#product_form")[0].reset();
								}else if($.trim(data) === 'PRODUCT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#product_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Product Updated Successfully");
								}else if($.trim(data) === 'MATERIAL EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Material already exists");
								}else if($.trim(data) === 'invalid factor'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Conv Factor cannot be 0 or null if UOM are not same");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#product_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Product Saved Successfully");
								}
                		} 
        			});
				}
			});

$('#edit_product_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#pro_name').val() == ""){
				showDangerToast_field_required();
				$('#pro_name').focus();	
				}
				else if($('#pro_code').val() == ""){
				showDangerToast_field_required();
				$('#pro_code').focus();	
				}
				else if($('#mat_code').val() == ""){
				showDangerToast_field_required();
				$('#mat_code').focus();	
				}
				else if($('#tech_spec').val() == ""){
				showDangerToast_field_required();
				$('#tech_spec').focus();	
				}
				else if($('#cat_id').val() == ""){
				showDangerToast_field_required();
				$('#cat_id').focus();	
				}
				else if($('#grp_id').val() == ""){
				showDangerToast_field_required();
				$('#grp_id').focus();	
				}
				else if($('#sub_grp_id').val() == ""){
				showDangerToast_field_required();
				$('#sub_grp_id').focus();	
				}
				else if($('#hsn').val() == ""){
				showDangerToast_field_required();
				$('#hsn').focus();	
				}
				else if($('#gst_rate').val() == ""){
				showDangerToast_field_required();
				$('#gst_rate').focus();	
				}
				else if($('#purchase_uom').val() == ""){
				showDangerToast_field_required();
				$('#purchase_uom').focus();	
				}
				else if($('#inventory_uom').val() == ""){
				showDangerToast_field_required();
				$('#inventory_uom').focus();	
				}
				else if($('#indent').val() == ""){
				showDangerToast_field_required();
				$('#indent').focus();	
				}
				else if($('#po_req').val() == ""){
				showDangerToast_field_required();
				$('#po_req').focus();	
				}
				else if($('#qc_req').val() == ""){
				showDangerToast_field_required();
				$('#qc_req').focus();	
				}
				else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}
				else{
				var request;
							request = $.ajax({
							url: "crud.php?page=edit_product",
							type: "post",
							data: $("#edit_product_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#edit_product_form")[0].reset();
								}else if($.trim(data) === 'PRODUCT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Product Updated Successfully");
								}else if($.trim(data) === 'MATERIAL EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Material already exists");
								}else if($.trim(data) === 'invalid factor'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("Conv Factor cannot be 0 or null if UOM are not same");
								}
                		} 
        			});
				}
			});
$('#contract').on('submit', function(e) {
				e.preventDefault();									   
				if($('#contract_desc').val() == ""){
				showDangerToast_name_validation();
				$('#contract_desc').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=contract",
							type: "post",
							data: $("#contract").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#contract")[0].reset();
								}else if($.trim(data) === 'CONTRACT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contract")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Contract Updated Successfully");
								}else if($.trim(data) === 'CONTRACT EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contract_desc").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("contract already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contract")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Contract Created Successfully");
								}
                		} 
        			});
				}
			});

		$('#contractpage').on('submit', function(e) {
				e.preventDefault();									   
				if($('#contract_unit_rate[1]').val() == ""){
				showDangerToast_name_validation();
				$('#contract_unit_rate[1]').focus();	
				}else if($('#select_contract[1]').val() == ""){
				showDangerToast_field_required();
				$('#select_contract[1]').focus();	
				}else if($('#contract_uom[1]').val() == ""){
				showDangerToast_field_required();
				$('#contract_uom[1]').focus();	
				}else if($('#contract_quantity[1]').val() == ""){
				showDangerToast_field_required();
				$('#contract_quantity[1]').focus();	
				}else if($('#contract_total_cost[1]').val() == ""){
				showDangerToast_field_required();
				$('#contract_total_cost[1]').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=contractpage",
							type: "post",
							data: $("#contractpage").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#contractpage")[0].reset();
								}else if($.trim(data) === 'CONTRACT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contractpage")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Contract Updated Successfully");
								}else if($.trim(data) === 'CONTRACT EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contract_unit_rate").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("contract already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#contractpage")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Contract Created Successfully");
								}
                		} 
        			});
				}
			});

		$('#tpi').on('submit', function(e) {
				e.preventDefault();
				if($('#tpi_name').val() == ""){
				showDangerToast_name_validation();
				$('#tpi_name').focus();	
				}else if($('#tpi_code').val() == ""){	
				showDangerToast_name_validation();
				$('#tpi_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=tpi",
							type: "post",
							data: $("#tpi").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#tpi")[0].reset();
								}else if($.trim(data) === 'TPI UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#tpi")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Tpi Updated Successfully");
								}else if($.trim(data) === 'TPI EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#tpi_code").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("tpi code already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#tpi")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Tpi Created Successfully");
								}
                		} 
        			});
				}
			}); 

	$('#uom').on('submit', function(e) {
				e.preventDefault();									   
				if($('#uom_name').val() == ""){
				showDangerToast_name_validation();					
				$('#uom_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=uom",
							type: "post",
							data: $("#uom").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#uom")[0].reset();
								}else if($.trim(data) === 'UOM UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#uom")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Uom Updated Successfully");
								}else if($.trim(data) === 'UOM EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#uom_name").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("uom already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#uom")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Uom Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#service').on('submit', function(e) {
				e.preventDefault();
				if($('#service_name').val() == ""){
				showDangerToast_name_validation();	
				$('#service_name').focus();	
				}else if($('#service_code').val() == ""){	
				showDangerToast_name_validation();
				$('#service_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=service",
							type: "post",
							data: $("#service").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#service")[0].reset();
								}else if($.trim(data) === 'SERVICE UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#service")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Service Updated Successfully");
								}else if($.trim(data) === 'SERVICE EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#service_code").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("service code already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#service")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Service Created Successfully");
								}
                		} 
        			});
				}
			});

	$('#activity').on('submit', function(e) {
				e.preventDefault();
				if($('#activity_name').val() == ""){
				showDangerToast_name_validation();
				$('#activity_name').focus();	
				}else if($('#activity_code').val() == ""){
				showDangerToast_name_validation();
				$('#activity_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=activity",
							type: "post",
							data: $("#activity").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#activity")[0].reset();
								}else if($.trim(data) === 'ACTIVITY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#activity")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Activity Updated Successfully");
								}else if($.trim(data) === 'ACTIVITY EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#activity_code").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("activity code already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#activity")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Activity Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#weld').on('submit', function(e) {
				e.preventDefault();
				if($('#weld_name').val() == ""){
				showDangerToast_name_validation();	
				$('#weld_name').focus();	
				}else if($('#weld_code').val() == ""){	
				showDangerToast_name_validation();
				$('#weld_code').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=weld",
							type: "post",
							data: $("#weld").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#weld")[0].reset();
								}else if($.trim(data) === 'WELD UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#weld")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Weld Updated Successfully");
								}else if($.trim(data) === 'WELD EXISTS'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#weld_code").focus();
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.error("weld code already exists");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#weld")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Weld Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#estimate').on('submit', function(e) {
				e.preventDefault();									   
				if($('#tab_name').val() == ""){					
				// showDangerToast_field_required();
				$('#tab_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=estimate",
							type: "post",
							data: $("#estimate").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#estimate")[0].reset();
								}else if($.trim(data) === 'ESTIMATE UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#estimate")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Estimate Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#estimate")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Estimate Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#status_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#status_name').val() == ""){
				showDangerToast_field_required();
				$('#status_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=calling_status",
							type: "post",
							data: $("#status_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#status_form")[0].reset();
								}else if($.trim(data) === 'STATUS UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#status_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Calling Status Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#status_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Calling Status Created Successfully");
								}
                		} 
        			});
				}
			});

		
		$('#state_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#state_name').val() == ""){
				showDangerToast_field_required();
				$('#state_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=state_name",
							type: "post",
							data: $("#state_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#state_form")[0].reset();
								}else if($.trim(data) === 'STATE UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#state_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("State Updated");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#state_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("State Created");
								}
                		} 
        			});
				}
			});

		
				$('#city_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#city_name').val() == ""){
				showDangerToast_field_required();
				$('#city_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=city_name",
							type: "post",
							data: $("#city_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#city_form")[0].reset();
								}else if($.trim(data) === 'CITY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#city_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("City Updated");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#city_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("City Created");
								}
                		} 
        			});
				}
			});


	$('#bank_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#bank_name').val() == ""){
				showDangerToast_field_required();
				$('#bank_name').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=bank",
							type: "post",
							data: $("#bank_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#bank_form")[0].reset();
								}else if($.trim(data) === 'BANK UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#bank_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Bank Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#bank_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Bank Created Successfully");
								}
                		} 
        			});
				}
			});

           $('#manpower_category').on('submit', function(e) {
				e.preventDefault();									   
				if($('#man_description').val() == ""){
				showDangerToast_field_required();
				$('#man_description').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=manpower_category",
							type: "post",
							data: $("#manpower_category").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#manpower_category")[0].reset();
								}else if($.trim(data) === 'MANPOWER CATEGORY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#manpower_category")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Category Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#manpower_category")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Category Created Successfully");
								}
                		} 
        			});
				}
			});

           $('#manpower').on('submit', function(e) {
				e.preventDefault();									   
				if($('#manpower_des').val() == ""){
				showDangerToast_field_required();
				$('#manpower_des').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=manpower",
							type: "post",
							data: $("#manpower").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#manpower")[0].reset();
								}else if($.trim(data) === 'MANPOWER CATEGORY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#manpower")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Manpower Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#manpower")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Manpower Created Successfully");
								}
                		} 
        			});
				}
			});


	$('#add_material_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#material_category').val() == ""){
				showDangerToast_field_required();
				$('#material_category').focus();	
				}else if($('#material_name').val() == ""){
				showDangerToast_field_required();
				$('#material_name').focus();	
				}else if($('#unit_name').val() == ""){
				showDangerToast_field_required();
				$('#unit_name').focus();	
				}else if($('#cum_val').val() == ""){
				showDangerToast_field_required();
				$('#cum_val').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=material_name",
							type: "post",
							data: $("#add_material_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#add_material_form")[0].reset();
								}else if($.trim(data) === 'MATERIAL MASTER UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#add_material_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("MATERIAL MASTER UPDATED");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#add_material_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("MATERIAL MASTER CREATED");
								}
                		} 
        			});
				}
			});
	$('#sub_category_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#material_category').val() == ""){
				showDangerToast_field_required();
				$('#material_category').focus();	
				}else if($('#sub_category').val() == ""){
				showDangerToast_field_required();
				$('#sub_category').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=sub_category",
							type: "post",
							data: $("#sub_category_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#sub_category_form")[0].reset();
								}else if($.trim(data) === 'SUB CATEGORY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#sub_category_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Sub Category Updated");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#sub_category_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Sub Category Created");
								}
                		} 
        			});
				}
			});

	$('#add_user_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#user_name').val() == ""){
				showDangerToast_field_required();
				$('#user_name').focus();	
				}else if($('#user_email').val() == ""){
				showDangerToast_field_required();
				$('#user_email').focus();	
				}else if($('#user_mobile').val() == ""){
				showDangerToast_field_required();
				$('#user_mobile').focus();	
				}else if($('#joining_date').val() == ""){
				showDangerToast_field_required();
				$('#joining_date').focus();	
				}else if($('#project_name').val() == ""){
				showDangerToast_field_required();
				$('#project_name').focus();	
				}else if($('#department').val() == ""){
				showDangerToast_field_required();
				$('#department').focus();	
				}else if($('#designation').val() == ""){
				showDangerToast_field_required();
				$('#designation').focus();	
				}else if($('#user_password').val() == ""){
				showDangerToast_field_required();
				$('#user_password').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=add_user",
							type: "post",
							data: $("#add_user_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#add_user_form")[0].reset();
									alertify.success("User Created Successfully");
									setTimeout("window.location.href='view_users.php';",2000);
								}
                		} 
        			});
				}
			});
	$('#add_profile_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#role').val() == ""){
				showDangerToast_field_required();
				$('#role').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=add_profile",
							type: "post",
							data: $("#add_profile_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#add_profile_form")[0].reset();
									alertify.success("Profile Created Successfully");
								}
                		} 
        			});
				}
			});

	$('#company_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#company_name').val() == ""){
				showDangerToast_field_required();
				$('#company_name').focus();	
				}else if($('#company_code').val() == ""){
				showDangerToast_field_required();
				$('#company_code').focus();	
				}else if($('#company_number').val() == ""){
				showDangerToast_field_required();
				$('#company_number').focus();	
				}else if($('#landline').val() == ""){
				showDangerToast_field_required();
				$('#landline').focus();	
				}else if($('#pancard').val() == ""){
				showDangerToast_field_required();
				$('#pancard').focus();	
				}else if($('#gst_number').val() == ""){
				showDangerToast_field_required();
				$('#gst_number').focus();	
				}else if($('#register_date').val() == ""){
				showDangerToast_field_required();
				$('#register_date').focus();	
				}else if($('#address').val() == ""){
				showDangerToast_field_required();
				$('#address').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else if($('#company_email').val() == ""){
				showDangerToast_field_required();
				$('#company_email').focus();	
				}else if($('#website').val() == ""){
				showDangerToast_field_required();
				$('#website').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=add_company",
							type: "post",
							data: $("#company_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else if($.trim(data) === 'COMPANY UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#company_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Company Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#company_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Company Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#project_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#company').val() == ""){
				showDangerToast_field_required();
				$('#company').focus();	
				}else if($('#project_name').val() == ""){
				showDangerToast_field_required();
				$('#project_name').focus();	
				}else if($('#project_code').val() == ""){
				showDangerToast_field_required();
				$('#project_code').focus();	
				}else if($('#contact_person').val() == ""){
				showDangerToast_field_required();
				$('#contact_person').focus();	
				}else if($('#contact_number').val() == ""){
				showDangerToast_field_required();
				$('#contact_number').focus();	
				}else if($('#project_email').val() == ""){
				showDangerToast_field_required();
				$('#project_email').focus();	
				}else if($('#start_date').val() == ""){
				showDangerToast_field_required();
				$('#start_date').focus();	
				}else if($('#address').val() == ""){
				showDangerToast_field_required();
				$('#address').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=add_project",
							type: "post",
							data: $("#project_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else if($.trim(data) === 'PROJECT UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#project_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Project Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#project_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Project Created Successfully");
								}
                		} 
        			});
				}
			});
	$('#company_bank_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#company').val() == ""){
				showDangerToast_field_required();
				$('#company').focus();	
				}else if($('#bank_name').val() == ""){
				showDangerToast_field_required();
				$('#bank_name').focus();	
				}else if($('#account_number').val() == ""){
				showDangerToast_field_required();
				$('#account_number').focus();	
				}else if($('#account_type').val() == ""){
				showDangerToast_field_required();
				$('#account_type').focus();	
				}else if($('#ifsc_code').val() == ""){
				showDangerToast_field_required();
				$('#ifsc_code').focus();	
				}else if($('#bank_branch').val() == ""){
				showDangerToast_field_required();
				$('#bank_branch').focus();	
				}else if($('#bank_address').val() == ""){
				showDangerToast_field_required();
				$('#bank_address').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=company_bank",
							type: "post",
							data: $("#company_bank_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							$("#company_bank_form")[0].reset();
							alertify.error("Something Went Wrong");
								}else if($.trim(data) === 'BANK UPDATED'){
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#company_bank_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Bank Updated Successfully");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									$("#company_bank_form")[0].reset();
									$("#menu_manage").modal("hide");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Bank Created Successfully");
								}
                		} 
        			});
				}
			});
		$('#edit_user_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#user_name').val() == ""){
				showDangerToast_field_required();
				$('#user_name').focus();	
				}else if($('#user_email').val() == ""){
				showDangerToast_field_required();
				$('#user_email').focus();	
				}else if($('#user_mobile').val() == ""){
				showDangerToast_field_required();
				$('#user_mobile').focus();	
				}else if($('#joining_date').val() == ""){
				showDangerToast_field_required();
				$('#joining_date').focus();	
				}else if($('#project_name').val() == ""){
				showDangerToast_field_required();
				$('#project_name').focus();	
				}else if($('#department').val() == ""){
				showDangerToast_field_required();
				$('#department').focus();	
				}else if($('#designation').val() == ""){
				showDangerToast_field_required();
				$('#designation').focus();	
				}else if($('#user_password').val() == ""){
				showDangerToast_field_required();
				$('#user_password').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=edit_user",
							type: "post",
							data: $("#edit_user_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									$("#designation").html(data.designation);
									alertify.success("User Updated Successfully");
									setTimeout("window.location.href='view_users.php';",2000);
								}
                		} 
        			});
				}
			});
		
		$('#edit_profile_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#role').val() == ""){
				showDangerToast_field_required();
				$('#role').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=edit_profile",
							type: "post",
							data: $("#edit_profile_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("Profile Updated Successfully");
								}
                		} 
        			});
				}
			});
		
		$('#edit_kyc_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#user_name').val() == ""){
				showDangerToast_field_required();
				$('#user_name').focus();	
				}else if($('#user_email').val() == ""){
				showDangerToast_field_required();
				$('#user_email').focus();	
				}else if($('#user_mobile').val() == ""){
				showDangerToast_field_required();
				$('#user_mobile').focus();	
				}else if($('#joining_date').val() == ""){
				showDangerToast_field_required();
				$('#joining_date').focus();	
				}else if($('#project_name').val() == ""){
				showDangerToast_field_required();
				$('#project_name').focus();	
				}else if($('#department').val() == ""){
				showDangerToast_field_required();
				$('#department').focus();	
				}else if($('#designation').val() == ""){
				showDangerToast_field_required();
				$('#designation').focus();	
				}else if($('#user_password').val() == ""){
				showDangerToast_field_required();
				$('#user_password').focus();	
				}else if($('#status').val() == ""){
				showDangerToast_field_required();
				$('#status').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=edit_kyc",
							type: "post",
							data: $("#edit_kyc_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').hide("slow");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
							alertify.error("Something Went Wrong");
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									var table = $('#datatable1').DataTable();
									table.ajax.reload(null, false);
									alertify.success("User Updated Successfully");
									setTimeout("window.location.href='view_employee.php';",2000);
								}
                		} 
        			});
				}
			});
		



		

		$('#change_password_form').on('submit', function(e) {
				e.preventDefault();									   
				if($('#user_password').val() == ""){
				alertify.error("Password Is Required");
				$('#user_password').focus();	
				}else{
				var request;
							request = $.ajax({
							url: "crud.php?page=change_password",
							type: "post",
							data: $("#change_password_form").serialize(),
							beforeSend: function(){
					        $('#loader').show("slow");
							$('#add_button').attr('disabled','true');
							$('#add_button').hide("fast");
							},
							success:function(data){ 
							if($.trim(data) === 'ERROR'){
								alertify.error("Something Went Wrong");
								$("#change_password_form")[0].reset();
								}else{
									$('#loader').hide("slow");
									$('#add_button').show("slow");
									alertify.success("Profile Updated Successfully");
									setTimeout("window.location.href='dashboard.php';",1000);
									
								}
                		} 
        			});
				}
			});

		
	
});